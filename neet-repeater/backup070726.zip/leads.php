<?php

$lead_id=$_GET['lead_id'] ?? '';

header("Location: thankyou.php");

exit;

?>